package com.edusense.model;

import jakarta.persistence.*;

@Entity
@Table(name = "academic_records")
public class AcademicRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Student student;

    @ManyToOne(optional = false)
    private Course course;

    private double attendance;
    private double assignmentScore;
    private double examScore;
    private double previousExamScore;

    public AcademicRecord() {}

    public AcademicRecord(Student student, Course course, double attendance,
                          double assignmentScore, double examScore, double previousExamScore) {
        this.student = student;
        this.course = course;
        this.attendance = attendance;
        this.assignmentScore = assignmentScore;
        this.examScore = examScore;
        this.previousExamScore = previousExamScore;
    }

    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public double getAttendance() { return attendance; }
    public double getAssignmentScore() { return assignmentScore; }
    public double getExamScore() { return examScore; }
    public double getPreviousExamScore() { return previousExamScore; }

    public void setAttendance(double v) { attendance = v; }
    public void setAssignmentScore(double v) { assignmentScore = v; }
    public void setExamScore(double v) { examScore = v; }
    public void setPreviousExamScore(double v) { previousExamScore = v; }
}
