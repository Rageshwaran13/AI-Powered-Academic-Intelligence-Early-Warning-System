package com.edusense.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "risk_assessments")
public class RiskAssessment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Student student;

    private double riskScore;

    @Enumerated(EnumType.STRING)
    private RiskLevel riskLevel;

    @Column(length = 2000)
    private String reasons;

    @Column(length = 4000)
    private String recommendation;

    private LocalDateTime createdAt = LocalDateTime.now();

    public RiskAssessment() {}

    public RiskAssessment(Student student, double riskScore, RiskLevel riskLevel,
                           String reasons, String recommendation) {
        this.student = student;
        this.riskScore = riskScore;
        this.riskLevel = riskLevel;
        this.reasons = reasons;
        this.recommendation = recommendation;
    }

    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public double getRiskScore() { return riskScore; }
    public RiskLevel getRiskLevel() { return riskLevel; }
    public String getReasons() { return reasons; }
    public String getRecommendation() { return recommendation; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
