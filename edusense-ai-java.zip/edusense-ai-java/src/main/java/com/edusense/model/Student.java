package com.edusense.model;

import jakarta.persistence.*;

@Entity
@Table(name = "students")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    private User user;

    private String registerNumber;
    private String department;
    private String semester;

    public Student() {}

    public Student(User user, String registerNumber, String department, String semester) {
        this.user = user;
        this.registerNumber = registerNumber;
        this.department = department;
        this.semester = semester;
    }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public String getRegisterNumber() { return registerNumber; }
    public String getDepartment() { return department; }
    public String getSemester() { return semester; }

    public void setUser(User user) { this.user = user; }
    public void setRegisterNumber(String registerNumber) { this.registerNumber = registerNumber; }
    public void setDepartment(String department) { this.department = department; }
    public void setSemester(String semester) { this.semester = semester; }
}
