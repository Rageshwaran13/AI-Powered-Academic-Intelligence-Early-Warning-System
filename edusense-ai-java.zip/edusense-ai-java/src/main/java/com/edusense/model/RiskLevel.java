package com.edusense.model;

public enum RiskLevel {
    LOW, MEDIUM, HIGH
}
