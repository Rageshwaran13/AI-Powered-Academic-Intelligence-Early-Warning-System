package com.edusense.model;

public enum Role {
    STUDENT, TEACHER, ADMIN
}
