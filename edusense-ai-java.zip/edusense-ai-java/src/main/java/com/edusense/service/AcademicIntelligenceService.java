package com.edusense.service;

import com.edusense.model.*;
import com.edusense.repository.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AcademicIntelligenceService {

    private final StudentRepository studentRepository;
    private final AcademicRecordRepository recordRepository;
    private final RiskAssessmentRepository riskRepository;

    public AcademicIntelligenceService(StudentRepository studentRepository,
                                       AcademicRecordRepository recordRepository,
                                       RiskAssessmentRepository riskRepository) {
        this.studentRepository = studentRepository;
        this.recordRepository = recordRepository;
        this.riskRepository = riskRepository;
    }

    public Map<String, Object> analyzeStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));

        List<AcademicRecord> records = recordRepository.findByStudentId(studentId);
        if (records.isEmpty()) {
            return Map.of(
                    "studentId", studentId,
                    "message", "No academic records available",
                    "riskScore", 0,
                    "riskLevel", "UNKNOWN"
            );
        }

        double attendance = avg(records, AcademicRecord::getAttendance);
        double assignment = avg(records, AcademicRecord::getAssignmentScore);
        double exam = avg(records, AcademicRecord::getExamScore);
        double previous = avg(records, AcademicRecord::getPreviousExamScore);

        // Explainable weighted risk model.
        double performance = (assignment * 0.25) + (exam * 0.45) + (attendance * 0.30);
        double declinePenalty = Math.max(0, previous - exam) * 0.30;
        double riskScore = clamp(100 - performance + declinePenalty, 0, 100);

        RiskLevel level = riskScore >= 70 ? RiskLevel.HIGH
                : riskScore >= 40 ? RiskLevel.MEDIUM : RiskLevel.LOW;

        List<String> reasons = new ArrayList<>();
        if (attendance < 75) reasons.add("Attendance below 75%");
        if (assignment < 60) reasons.add("Low assignment performance");
        if (exam < 60) reasons.add("Low examination performance");
        if (exam < previous - 10) reasons.add("Significant decline from previous exam");

        List<String> weakSubjects = records.stream()
                .filter(r -> r.getExamScore() < 60)
                .sorted(Comparator.comparingDouble(AcademicRecord::getExamScore))
                .map(r -> r.getCourse().getName())
                .distinct()
                .collect(Collectors.toList());

        String recommendation = buildRecommendation(attendance, assignment, exam, weakSubjects, level);

        return new LinkedHashMap<>(Map.ofEntries(
                Map.entry("studentId", studentId),
                Map.entry("studentName", student.getUser().getName()),
                Map.entry("attendance", round(attendance)),
                Map.entry("assignmentAverage", round(assignment)),
                Map.entry("examAverage", round(exam)),
                Map.entry("previousExamAverage", round(previous)),
                Map.entry("riskScore", round(riskScore)),
                Map.entry("riskLevel", level.toString()),
                Map.entry("weakSubjects", weakSubjects),
                Map.entry("reasons", reasons),
                Map.entry("recommendation", recommendation)
        ));
    }

    public List<Map<String, Object>> analyzeAllStudents() {
        return studentRepository.findAll().stream()
                .map(s -> analyzeStudent(s.getId()))
                .toList();
    }

    private String buildRecommendation(double attendance, double assignment,
                                       double exam, List<String> weak, RiskLevel level) {
        List<String> actions = new ArrayList<>();
        if (attendance < 75) actions.add("Improve attendance to at least 75%");
        if (assignment < 60) actions.add("Complete pending assignments and review feedback");
        if (exam < 60) actions.add("Create a focused revision plan for upcoming exams");
        if (!weak.isEmpty()) actions.add("Prioritize weak subjects: " + String.join(", ", weak));
        if (actions.isEmpty()) actions.add("Maintain current study consistency and continue monitoring performance");

        return (level == RiskLevel.HIGH ? "Immediate attention recommended. " : "") +
                String.join(". ", actions) + ".";
    }

    private double avg(List<AcademicRecord> list, java.util.function.ToDoubleFunction<AcademicRecord> fn) {
        return list.stream().mapToDouble(fn).average().orElse(0);
    }

    private double clamp(double x, double min, double max) {
        return Math.max(min, Math.min(max, x));
    }

    private double round(double x) {
        return Math.round(x * 100.0) / 100.0;
    }
}
