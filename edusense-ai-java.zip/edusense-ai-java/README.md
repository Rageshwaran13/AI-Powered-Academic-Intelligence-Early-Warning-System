# EduSense AI — Java Edition

AI-Powered Academic Intelligence & Early Warning System.

## Stack
- Java 17
- Spring Boot 3.5
- Spring Web
- Spring Data JPA
- H2 database (easy local demo; can be switched to PostgreSQL)
- HTML/CSS/JavaScript demo dashboard
- Explainable academic risk engine written in Java

## Run

Install Java 17+ and Maven.

```bash
mvn spring-boot:run
```

Open:
- http://localhost:8080
- H2 console: http://localhost:8080/h2-console

H2 JDBC URL:
`jdbc:h2:file:./data/edusense`

## Demo accounts

student@demo.edu / demo123
teacher@demo.edu / demo123
admin@demo.edu / demo123

## Main APIs

GET `/api/students`
GET `/api/courses`
GET `/api/students/{id}/records`
GET `/api/students/{id}/intelligence`
GET `/api/admin/risk-dashboard`
POST `/api/auth/login`
GET `/api/health`

## AI logic

Risk is an explainable weighted model:

Performance =
25% assignment +
45% examination +
30% attendance

Risk =
100 - performance + decline penalty

Risk levels:
- LOW: < 40
- MEDIUM: 40–69.99
- HIGH: >= 70

The implementation is intentionally explainable for a hackathon MVP. A trained ML model can later replace the scoring service without changing the REST API.

## Important production upgrades

- BCrypt password hashing
- Spring Security + JWT
- PostgreSQL
- Role-based access control
- Real ML model/service
- Audit logging
- Validation and exception handling
- Teacher/admin CRUD
- Attendance/assignment/exam entry screens
- Intervention tracking
